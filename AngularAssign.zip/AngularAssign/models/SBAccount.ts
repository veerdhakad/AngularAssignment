export class SBAccount {
  accountNumber: number;
  accontHolderName: string;
  address: string;
  currentAmount: number;
  constructor(accountNumber: number, accountHolderName: string, address: string, currentAmount: number) {
       this.accountNumber = accountNumber;
       this.accontHolderName = accountHolderName;
       this.currentAmount = currentAmount;
       this.address = address;
  }
}
