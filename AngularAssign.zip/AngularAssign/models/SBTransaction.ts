export class SBTransaction {
  transactionId: string ;
  transactionAccount: number;
  transactionDate: string;
  transactionAmount: number;
  transactionType: string;
  constructor(transactionId: string, transactionAccount: number, transactionDate: string, transactionAmount:number,transactionType:string ){
    this.transactionId = transactionId;
    this.transactionAccount = transactionAccount;
    this.transactionDate = transactionDate;
    this.transactionAmount = transactionAmount;
    this.transactionType = transactionType;
 }
}
